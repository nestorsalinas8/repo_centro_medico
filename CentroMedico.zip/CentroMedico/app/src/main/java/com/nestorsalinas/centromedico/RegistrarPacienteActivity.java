package com.nestorsalinas.centromedico;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegistrarPacienteActivity extends AppCompatActivity {

    private EditText edtDni, edtNombre, edtContacto, edtHistoriaMedica;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_paciente);

        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        edtDni = findViewById(R.id.edtDni);
        edtNombre = findViewById(R.id.edtNombre);
        edtContacto = findViewById(R.id.edtContacto);
        edtHistoriaMedica = findViewById(R.id.edtHistoriaMedica);

        Button btnRegistrar = findViewById(R.id.btnRegistrar);
        Button btnCancelar = findViewById(R.id.btnCancelar);

        if (btnCancelar != null) {
            btnCancelar.setOnClickListener(v -> finish());
        }

        if (btnRegistrar != null) {
            btnRegistrar.setOnClickListener(v -> {
                String nom = edtNombre != null ? edtNombre.getText().toString().trim() : "";
                if (nom.isEmpty()) {
                    Toast.makeText(this, "Ingrese el nombre del paciente", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(this, "Paciente " + nom + " registrado con éxito", Toast.LENGTH_SHORT).show();
                finish();
            });
        }
    }
}