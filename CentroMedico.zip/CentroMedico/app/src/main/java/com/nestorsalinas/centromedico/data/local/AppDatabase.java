package com.nestorsalinas.centromedico.data.local;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.nestorsalinas.centromedico.data.local.dao.*;
import com.nestorsalinas.centromedico.data.local.entity.*;

@Database(entities = {
        EmpleadoEntity.class,
        PacienteEntity.class,
        CitaEntity.class,
        SignosVitalesEntity.class,
        FacturaEntity.class
}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    private static volatile AppDatabase INSTANCE;

    public abstract EmpleadoDao empleadoDao();
    public abstract PacienteDao pacienteDao();
    public abstract CitaDao citaDao();
    public abstract SignosDao signosDao();
    public abstract FacturaDao facturaDao();

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "agenda_citas.db")
                            .createFromAsset("agenda_citas.db")
                            .allowMainThreadQueries()
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}