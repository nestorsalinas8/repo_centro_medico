package com.nestorsalinas.centromedico;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ContratarEmpleadoActivity extends AppCompatActivity {

    private EditText edtNombres, edtApellidos, edtIdentidad, edtEdad, edtIdEmpleado, edtFechaIngreso, edtSalario, edtEspecialidad, edtColegiado;
    private Button btnContratar, btnRoleMedico, btnRoleEnfermero, btnRoleAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contratar_empleado);

        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        edtNombres = findViewById(R.id.edtNombres);
        edtApellidos = findViewById(R.id.edtApellidos);
        edtIdentidad = findViewById(R.id.edtIdentidad);
        edtEdad = findViewById(R.id.edtEdad);
        edtIdEmpleado = findViewById(R.id.edtIdEmpleado);
        edtFechaIngreso = findViewById(R.id.edtFechaIngreso);
        edtSalario = findViewById(R.id.edtSalario);
        edtEspecialidad = findViewById(R.id.edtEspecialidad);
        edtColegiado = findViewById(R.id.edtColegiado);

        btnRoleMedico = findViewById(R.id.btnRoleMedico);
        btnRoleEnfermero = findViewById(R.id.btnRoleEnfermero);
        btnRoleAdmin = findViewById(R.id.btnRoleAdmin);
        btnContratar = findViewById(R.id.btnContratar);

        if (btnContratar != null) {
            btnContratar.setOnClickListener(v -> {
                String nom = edtNombres != null ? edtNombres.getText().toString().trim() : "";
                String ape = edtApellidos != null ? edtApellidos.getText().toString().trim() : "";

                if (nom.isEmpty() || ape.isEmpty()) {
                    Toast.makeText(this, "Por favor ingrese al menos nombre y apellido", Toast.LENGTH_SHORT).show();
                    return;
                }

                Toast.makeText(this, "Empleado " + nom + " " + ape + " contratado con éxito", Toast.LENGTH_SHORT).show();
                finish();
            });
        }
    }
}