-- Datos de prueba Centro Médico
INSERT INTO empleados (id, idEmpleado, correo, passwordHash, rol, nombres, apellidos) VALUES
(1, '1', 'laura.gomez@mavata.test', 'medico1-2026', 'Medico', 'Laura', 'Gómez'),
(2, '2', 'andres.mosquera@mavata.test', 'medico2-2026', 'Medico', 'Andrés', 'Mosquera'),
(3, '3', 'carmen.torres@mavata.test', 'medico3-2026', 'Medico', 'Carmen', 'Torres'),
(4, '4', 'julian.herrera@mavata.test', 'medico4-2026', 'Medico', 'Julián', 'Herrera'),
(5, '5', 'patricia.ruiz@mavata.test', 'medico5-2026', 'Medico', 'Patricia', 'Ruiz'),
(6, '6', 'sofia.munoz@mavata.test', 'enfermero1-2026', 'Enfermero', 'Sofía', 'Muñoz'),
(7, '7', 'daniela.ordonez@mavata.test', 'enfermero2-2026', 'Enfermero', 'Daniela', 'Ordóñez'),
(8, '8', 'valentina.quintero@mavata.test', 'enfermero3-2026', 'Enfermero', 'Valentina', 'Quintero'),
(9, '9', 'ana.fajardo@mavata.test', 'enfermero4-2026', 'Enfermero', 'Ana', 'Fajardo'),
(10, '10', 'camila.rojas@mavata.test', 'enfermero5-2026', 'Enfermero', 'Camila', 'Rojas'),
(11, '11', 'superadmin@mavata.test', 'superadmin-2026', 'Administrativo', 'Super', 'Admin'),
(12, '12', 'recepcion@mavata.test', 'recepcion1-2026', 'Recepcion', 'Recepcion', 'Principal');
